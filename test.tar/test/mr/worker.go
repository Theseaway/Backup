package mr

import (
	"fmt"
	"log"
	"net/rpc"
	"time"
)

type KeyValue struct {
	Key   string
	Value string
}

//
// main/mrworker.go calls this function.
//
func Worker() {
	loop := 1
	for {
		fmt.Printf("%dTH LOOP START!\n", loop)
		loop++
		wrk := WorkerParameter{}
		timef := TaskState{}
		call("Coordinator.TaskGet", &timef, &wrk)
		fmt.Printf("wrk is :%v\n", wrk)
		time.Sleep(100 * time.Second)
		break
	}
}

func call(rpcname string, args interface{}, reply interface{}) bool {
	// c, err := rpc.DialHTTP("tcp", "127.0.0.1"+":1234")
	sockname := coordinatorSock()
	c, err := rpc.DialHTTP("unix", sockname)
	if err != nil {
		log.Fatal("dialing:", err)
	}
	defer c.Close()

	err = c.Call(rpcname, args, reply)
	if err == nil {
		return true
	}

	fmt.Println(err)
	return false
}

package mr

import (
	"log"
	"sync"
	"time"
)
import "net"
import "os"
import "net/rpc"
import "net/http"

const (
	wait = iota
	busy
	done
	pending
)

type Coordinator struct {
	FileList   []string
	ActiveTime time.Time
	NReduce    int

	timemu   *sync.Mutex
	mapState []int
	mapTime  []time.Time
	mapDone  bool

	reduceState []int
	reduceTime  []time.Time
	reduceDone  bool
}

func (c *Coordinator) KeepAlive() {
	c.timemu.Lock()
	c.ActiveTime = time.Now().UTC()
	c.timemu.Unlock()
}

// Your code here -- RPC handlers for the worker to call.

func (c *Coordinator) TaskGet(wrk *WorkerParameter, times *TimeF) error {

	file := c.FileList
	wrk.File = file
	reduce := c.NReduce
	wrk.Reduce = reduce

	now := time.Now().UTC()
	times.TimeStart = now
	inum := len(c.FileList)
	for i := 0; i < inum; i++ {
		c.mapState[i] = busy
		c.mapTime[i] = now
	}
	return nil
}

func (c *Coordinator) MapTaskFinished(task *TaskState) {
	c.mapState[task.Index] = task.State
	c.mapTime[task.Index] = time.Now().UTC()
	c.timemu.Lock()
	c.ActiveTime = time.Now().UTC()
	c.timemu.Unlock()
}

//
// start a thread that listens for RPCs from worker.go
//
func (c *Coordinator) server() {
	rpc.Register(c)
	rpc.HandleHTTP()
	//c.KeepAlive()
	sockname := coordinatorSock()
	os.Remove(sockname)
	l, e := net.Listen("unix", sockname)
	if e != nil {
		log.Fatal("listen error:", e)
	}
	go http.Serve(l, nil)
}

//
// main/mrcoordinator.go calls Done() periodically to find out
// if the entire job has finished.
//
func (c *Coordinator) Done() bool {
	dur := time.Since(c.ActiveTime) / time.Millisecond
	if dur > 100*1000 {
		return true
	} else {
		return false
	}
}

//
// create a Coordinator.
// main/mrcoordinator.go calls this function.
// nReduce is the number of reduce tasks to use.
//
func MakeCoordinator(files []string, nReduce int) *Coordinator {
	c := Coordinator{}
	c.timemu = &sync.Mutex{}
	c.FileList = files
	inputNum := len(files)
	c.NReduce = nReduce
	now := time.Now().UTC()
	c.KeepAlive()
	c.mapState = make([]int, inputNum)
	c.mapTime = make([]time.Time, inputNum)
	c.mapDone = false
	for i := 0; i < inputNum; i++ {
		c.mapTime[i] = now
		c.mapState[i] = wait
	}

	c.reduceState = make([]int, c.NReduce)
	c.reduceTime = make([]time.Time, c.NReduce)
	c.reduceDone = false
	for i := 0; i < c.NReduce; i++ {
		c.reduceTime[i] = now
		c.reduceState[i] = wait
	}

	c.server()
	return &c
}
